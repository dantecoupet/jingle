from django.apps import AppConfig


class JingleConfig(AppConfig):
    name = 'jingle'
